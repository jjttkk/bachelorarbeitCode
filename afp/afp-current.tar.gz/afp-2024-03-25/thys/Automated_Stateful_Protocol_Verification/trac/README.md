# Interface between Isabelle and trac specifications

## Prerequisites 

* For re-generating the parser, ml-lex and ml-yacc are required


## License

This project is licensed under a 2-clause BSD-style license.

SPDX-License-Identifier: BSD-2-Clause

